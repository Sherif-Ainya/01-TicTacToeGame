﻿namespace WindowsFormsApp
{
	partial class form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.pb1 = new System.Windows.Forms.PictureBox();
			this.lbTitle = new System.Windows.Forms.Label();
			this.pb2 = new System.Windows.Forms.PictureBox();
			this.pb3 = new System.Windows.Forms.PictureBox();
			this.pb4 = new System.Windows.Forms.PictureBox();
			this.pb5 = new System.Windows.Forms.PictureBox();
			this.pb6 = new System.Windows.Forms.PictureBox();
			this.pb7 = new System.Windows.Forms.PictureBox();
			this.pb8 = new System.Windows.Forms.PictureBox();
			this.pb9 = new System.Windows.Forms.PictureBox();
			this.lb1 = new System.Windows.Forms.Label();
			this.lb2 = new System.Windows.Forms.Label();
			this.lbTurn = new System.Windows.Forms.Label();
			this.lbWinning = new System.Windows.Forms.Label();
			this.btnRestart = new System.Windows.Forms.Button();
			this.pbTitle1 = new System.Windows.Forms.PictureBox();
			this.pbTitle2 = new System.Windows.Forms.PictureBox();
			this.btnExit = new System.Windows.Forms.Button();
			this.lbSlash = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.pb1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pb2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pb3)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pb4)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pb5)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pb6)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pb7)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pb8)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pb9)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pbTitle1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pbTitle2)).BeginInit();
			this.SuspendLayout();
			// 
			// pb1
			// 
			this.pb1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.pb1.Image = global::WindowsFormsApp.Properties.Resources.question_mark_96;
			this.pb1.Location = new System.Drawing.Point(478, 202);
			this.pb1.Name = "pb1";
			this.pb1.Size = new System.Drawing.Size(113, 109);
			this.pb1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pb1.TabIndex = 0;
			this.pb1.TabStop = false;
			this.pb1.Tag = "?";
			this.pb1.Click += new System.EventHandler(this.PictureBox_Click);
			// 
			// lbTitle
			// 
			this.lbTitle.AutoSize = true;
			this.lbTitle.Font = new System.Drawing.Font("Monotype Corsiva", 48F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic) 
                | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
			this.lbTitle.Location = new System.Drawing.Point(440, 60);
			this.lbTitle.Name = "lbTitle";
			this.lbTitle.Size = new System.Drawing.Size(567, 97);
			this.lbTitle.TabIndex = 9;
			this.lbTitle.Text = "Tic-Tac-Toe Game";
			// 
			// pb2
			// 
			this.pb2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.pb2.Image = global::WindowsFormsApp.Properties.Resources.question_mark_96;
			this.pb2.Location = new System.Drawing.Point(668, 202);
			this.pb2.Name = "pb2";
			this.pb2.Size = new System.Drawing.Size(113, 109);
			this.pb2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pb2.TabIndex = 10;
			this.pb2.TabStop = false;
			this.pb2.Tag = "?";
			this.pb2.Click += new System.EventHandler(this.PictureBox_Click);
			// 
			// pb3
			// 
			this.pb3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.pb3.Image = global::WindowsFormsApp.Properties.Resources.question_mark_96;
			this.pb3.Location = new System.Drawing.Point(848, 202);
			this.pb3.Name = "pb3";
			this.pb3.Size = new System.Drawing.Size(113, 109);
			this.pb3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pb3.TabIndex = 11;
			this.pb3.TabStop = false;
			this.pb3.Tag = "?";
			this.pb3.Click += new System.EventHandler(this.PictureBox_Click);
			// 
			// pb4
			// 
			this.pb4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.pb4.Image = global::WindowsFormsApp.Properties.Resources.question_mark_96;
			this.pb4.Location = new System.Drawing.Point(478, 345);
			this.pb4.Name = "pb4";
			this.pb4.Size = new System.Drawing.Size(113, 109);
			this.pb4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pb4.TabIndex = 12;
			this.pb4.TabStop = false;
			this.pb4.Tag = "?";
			this.pb4.Click += new System.EventHandler(this.PictureBox_Click);
			// 
			// pb5
			// 
			this.pb5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.pb5.Image = global::WindowsFormsApp.Properties.Resources.question_mark_96;
			this.pb5.Location = new System.Drawing.Point(668, 345);
			this.pb5.Name = "pb5";
			this.pb5.Size = new System.Drawing.Size(113, 109);
			this.pb5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pb5.TabIndex = 13;
			this.pb5.TabStop = false;
			this.pb5.Tag = "?";
			this.pb5.Click += new System.EventHandler(this.PictureBox_Click);
			// 
			// pb6
			// 
			this.pb6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.pb6.Image = global::WindowsFormsApp.Properties.Resources.question_mark_96;
			this.pb6.Location = new System.Drawing.Point(848, 345);
			this.pb6.Name = "pb6";
			this.pb6.Size = new System.Drawing.Size(113, 109);
			this.pb6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pb6.TabIndex = 14;
			this.pb6.TabStop = false;
			this.pb6.Tag = "?";
			this.pb6.Click += new System.EventHandler(this.PictureBox_Click);
			// 
			// pb7
			// 
			this.pb7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.pb7.Image = global::WindowsFormsApp.Properties.Resources.question_mark_96;
			this.pb7.Location = new System.Drawing.Point(478, 496);
			this.pb7.Name = "pb7";
			this.pb7.Size = new System.Drawing.Size(113, 109);
			this.pb7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pb7.TabIndex = 15;
			this.pb7.TabStop = false;
			this.pb7.Tag = "?";
			this.pb7.Click += new System.EventHandler(this.PictureBox_Click);
			// 
			// pb8
			// 
			this.pb8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.pb8.Image = global::WindowsFormsApp.Properties.Resources.question_mark_96;
			this.pb8.Location = new System.Drawing.Point(668, 496);
			this.pb8.Name = "pb8";
			this.pb8.Size = new System.Drawing.Size(113, 109);
			this.pb8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pb8.TabIndex = 16;
			this.pb8.TabStop = false;
			this.pb8.Tag = "?";
			this.pb8.Click += new System.EventHandler(this.PictureBox_Click);
			// 
			// pb9
			// 
			this.pb9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
			this.pb9.Image = global::WindowsFormsApp.Properties.Resources.question_mark_96;
			this.pb9.Location = new System.Drawing.Point(848, 496);
			this.pb9.Name = "pb9";
			this.pb9.Size = new System.Drawing.Size(113, 109);
			this.pb9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pb9.TabIndex = 17;
			this.pb9.TabStop = false;
			this.pb9.Tag = "?";
			this.pb9.Click += new System.EventHandler(this.PictureBox_Click);
			// 
			// lb1
			// 
			this.lb1.Font = new System.Drawing.Font("Microsoft YaHei", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lb1.ForeColor = System.Drawing.Color.Lime;
			this.lb1.Location = new System.Drawing.Point(151, 175);
			this.lb1.Name = "lb1";
			this.lb1.Size = new System.Drawing.Size(120, 50);
			this.lb1.TabIndex = 18;
			this.lb1.Text = "Turn";
			this.lb1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lb2
			// 
			this.lb2.Font = new System.Drawing.Font("Microsoft YaHei", 20F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lb2.ForeColor = System.Drawing.Color.Lime;
			this.lb2.Location = new System.Drawing.Point(111, 364);
			this.lb2.Name = "lb2";
			this.lb2.Size = new System.Drawing.Size(200, 45);
			this.lb2.TabIndex = 19;
			this.lb2.Text = "Winning";
			this.lb2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lbTurn
			// 
			this.lbTurn.Font = new System.Drawing.Font("Monotype Corsiva", 35F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbTurn.ForeColor = System.Drawing.Color.Yellow;
			this.lbTurn.Location = new System.Drawing.Point(29, 236);
			this.lbTurn.Name = "lbTurn";
			this.lbTurn.Size = new System.Drawing.Size(380, 75);
			this.lbTurn.TabIndex = 20;
			this.lbTurn.Tag = "X";
			this.lbTurn.Text = "Player1 [X]";
			this.lbTurn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// lbWinning
			// 
			this.lbWinning.Font = new System.Drawing.Font("Monotype Corsiva", 35F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbWinning.ForeColor = System.Drawing.Color.Fuchsia;
			this.lbWinning.Location = new System.Drawing.Point(43, 419);
			this.lbWinning.Name = "lbWinning";
			this.lbWinning.Size = new System.Drawing.Size(375, 90);
			this.lbWinning.TabIndex = 21;
			this.lbWinning.Tag = "";
			this.lbWinning.Text = "In Prograss...";
			this.lbWinning.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// btnRestart
			// 
			this.btnRestart.BackColor = System.Drawing.Color.DimGray;
			this.btnRestart.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
			this.btnRestart.FlatAppearance.BorderSize = 3;
			this.btnRestart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnRestart.Font = new System.Drawing.Font("Bell MT", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnRestart.Location = new System.Drawing.Point(67, 533);
			this.btnRestart.Name = "btnRestart";
			this.btnRestart.Size = new System.Drawing.Size(301, 114);
			this.btnRestart.TabIndex = 0;
			this.btnRestart.Text = "Restart The Game";
			this.btnRestart.UseVisualStyleBackColor = false;
			this.btnRestart.Click += new System.EventHandler(this.btnRestart_Click);
			// 
			// pbTitle1
			// 
			this.pbTitle1.BackColor = System.Drawing.Color.Transparent;
			this.pbTitle1.Image = global::WindowsFormsApp.Properties.Resources.X;
			this.pbTitle1.Location = new System.Drawing.Point(91, -1);
			this.pbTitle1.Name = "pbTitle1";
			this.pbTitle1.Size = new System.Drawing.Size(89, 113);
			this.pbTitle1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pbTitle1.TabIndex = 23;
			this.pbTitle1.TabStop = false;
			// 
			// pbTitle2
			// 
			this.pbTitle2.BackColor = System.Drawing.Color.Transparent;
			this.pbTitle2.Image = global::WindowsFormsApp.Properties.Resources.O;
			this.pbTitle2.Location = new System.Drawing.Point(222, 28);
			this.pbTitle2.Name = "pbTitle2";
			this.pbTitle2.Size = new System.Drawing.Size(89, 113);
			this.pbTitle2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pbTitle2.TabIndex = 24;
			this.pbTitle2.TabStop = false;
			// 
			// btnExit
			// 
			this.btnExit.BackColor = System.Drawing.Color.DimGray;
			this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnExit.FlatAppearance.BorderColor = System.Drawing.Color.Red;
			this.btnExit.FlatAppearance.BorderSize = 3;
			this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.btnExit.Font = new System.Drawing.Font("Bell MT", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnExit.Location = new System.Drawing.Point(996, 647);
			this.btnExit.Name = "btnExit";
			this.btnExit.Size = new System.Drawing.Size(84, 40);
			this.btnExit.TabIndex = 1;
			this.btnExit.Text = "Exit";
			this.btnExit.UseVisualStyleBackColor = false;
			this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
			// 
			// lbSlash
			// 
			this.lbSlash.AutoSize = true;
			this.lbSlash.BackColor = System.Drawing.Color.Black;
			this.lbSlash.Font = new System.Drawing.Font("Microsoft Sans Serif", 70F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lbSlash.ForeColor = System.Drawing.Color.Red;
			this.lbSlash.Location = new System.Drawing.Point(161, 9);
			this.lbSlash.Name = "lbSlash";
			this.lbSlash.Size = new System.Drawing.Size(88, 132);
			this.lbSlash.TabIndex = 25;
			this.lbSlash.Text = "/";
			// 
			// form
			// 
			this.AcceptButton = this.btnRestart;
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.Black;
			this.CancelButton = this.btnExit;
			this.ClientSize = new System.Drawing.Size(1080, 687);
			this.Controls.Add(this.pbTitle2);
			this.Controls.Add(this.pbTitle1);
			this.Controls.Add(this.btnExit);
			this.Controls.Add(this.lbTurn);
			this.Controls.Add(this.lb1);
			this.Controls.Add(this.btnRestart);
			this.Controls.Add(this.lbWinning);
			this.Controls.Add(this.lb2);
			this.Controls.Add(this.pb9);
			this.Controls.Add(this.pb8);
			this.Controls.Add(this.pb7);
			this.Controls.Add(this.pb6);
			this.Controls.Add(this.pb5);
			this.Controls.Add(this.pb4);
			this.Controls.Add(this.pb3);
			this.Controls.Add(this.pb2);
			this.Controls.Add(this.lbTitle);
			this.Controls.Add(this.pb1);
			this.Controls.Add(this.lbSlash);
			this.Name = "form";
			this.Tag = "0";
			this.Text = "Tic-Tac-Toe My Solution";
			this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
			((System.ComponentModel.ISupportInitialize)(this.pb1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pb2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pb3)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pb4)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pb5)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pb6)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pb7)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pb8)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pb9)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pbTitle1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pbTitle2)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.PictureBox pb1;
		private System.Windows.Forms.Label lbTitle;
		private System.Windows.Forms.PictureBox pb2;
		private System.Windows.Forms.PictureBox pb3;
		private System.Windows.Forms.PictureBox pb4;
		private System.Windows.Forms.PictureBox pb5;
		private System.Windows.Forms.PictureBox pb6;
		private System.Windows.Forms.PictureBox pb7;
		private System.Windows.Forms.PictureBox pb8;
		private System.Windows.Forms.PictureBox pb9;
		private System.Windows.Forms.Label lb1;
		private System.Windows.Forms.Label lb2;
		private System.Windows.Forms.Label lbTurn;
		private System.Windows.Forms.Label lbWinning;
		private System.Windows.Forms.Button btnRestart;
		private System.Windows.Forms.PictureBox pbTitle1;
		private System.Windows.Forms.PictureBox pbTitle2;
		private System.Windows.Forms.Button btnExit;
		private System.Windows.Forms.Label lbSlash;
	}
}

