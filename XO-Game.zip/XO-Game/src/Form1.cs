﻿using System;
using System.Drawing;
using System.Windows.Forms;
using WindowsFormsApp.Properties;

namespace WindowsFormsApp
{
	public partial class form : Form
	{
		public form()
		{
			InitializeComponent();
		}
		private void Form1_Paint(object sender, PaintEventArgs e)
		{
			Color colorName = Color.FromArgb(255, 22, 234, 233);
			Pen penName = new Pen(colorName);
			penName.Width = 7;
			penName.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
			penName.StartCap = System.Drawing.Drawing2D.LineCap.Round;
			penName.EndCap = System.Drawing.Drawing2D.LineCap.Round;

			Color colorName1 = Color.FromArgb(255, 77, 246, 36);
			Pen penName1 = new Pen(colorName1);
			penName1.Width = 10;
			penName1.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
			penName1.StartCap = System.Drawing.Drawing2D.LineCap.Square;
			penName1.EndCap = System.Drawing.Drawing2D.LineCap.Square;

			Color colorName2 = Color.FromArgb(255, 255, 0, 0);
			Pen penName2 = new Pen(colorName2);
			penName2.Width = 10;
			penName2.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
			penName2.StartCap = System.Drawing.Drawing2D.LineCap.Square;
			penName2.EndCap = System.Drawing.Drawing2D.LineCap.Square;


			//  افقي
			e.Graphics.DrawLine(penName, 335, (140 + (510 - 140) / 3), 750, (140 + (510 - 140) / 3));
			e.Graphics.DrawLine(penName, 335, (140 + (510 - 140) * 2 / 3), 750, (140 + (510 - 140) * 2 / 3));

			e.Graphics.DrawLine(penName, (335 + (750 - 335) / 3), 140, (335 + (750 - 335) / 3), 510);
			e.Graphics.DrawLine(penName, (335 + (750 - 335) * 2 / 3), 140, (335 + (750 - 335) * 2 / 3), 510);

			e.Graphics.DrawRectangle(penName1, 335, 140, (750 - 335), (510 - 140));


			//e.Graphics.DrawLine(penName2, 50, 90, 90, 30);
		}


		private int _movesNumber = 1;

		private void RestartPictureBox(PictureBox pictureBoxName)
		{
			pictureBoxName.Image = Resources.question_mark_96;
			pictureBoxName.Tag = "?";
			pictureBoxName.BackColor = Color.Magenta;
			pictureBoxName.Enabled = true;
		}
		private void DisablePictureBoxes()
		{
			pb1.Enabled = false;
			pb2.Enabled = false;
			pb3.Enabled = false;
			pb4.Enabled = false;
			pb5.Enabled = false;
			pb6.Enabled = false;
			pb7.Enabled = false;
			pb8.Enabled = false;
			pb9.Enabled = false;
		}
		private void RestartTheGame()
		{
			lbTurn.Text = "Player1 [X]";
			lbWinning.Text = "In Prograss...";
			lbTurn.Tag = "X";
			_movesNumber = 1;

			RestartPictureBox((PictureBox)pb1);
			RestartPictureBox((PictureBox)pb2);
			RestartPictureBox((PictureBox)pb3);
			RestartPictureBox((PictureBox)pb4);
			RestartPictureBox((PictureBox)pb5);
			RestartPictureBox((PictureBox)pb6);
			RestartPictureBox((PictureBox)pb7);
			RestartPictureBox((PictureBox)pb8);
			RestartPictureBox((PictureBox)pb9);
		}

		private void ChangeTurn()
		{
			if (lbTurn.Tag.ToString() == "X")
			{
				lbTurn.Tag = "O";
				lbTurn.Text = "Player2 [O]";
				return;
			}
			lbTurn.Tag = "X";
			lbTurn.Text = "Player1 [X]";
		}
		private string CheckWinnerReturnTag()
		{
			String checkTag = "?";

			if (pb1.Tag.ToString() != "?")
			{
				if (pb1.Tag == pb2.Tag && pb1.Tag == pb3.Tag)
				{
					pb1.BackColor = Color.White; pb2.BackColor = Color.White; pb3.BackColor = Color.White;
					checkTag = pb1.Tag.ToString();
				}
				if (pb1.Tag == pb4.Tag && pb1.Tag == pb7.Tag)
				{
					pb1.BackColor = Color.White; pb4.BackColor = Color.White; pb7.BackColor = Color.White;
					checkTag = pb1.Tag.ToString();
				}
				if (pb1.Tag == pb5.Tag && pb1.Tag == pb9.Tag)
				{
					pb1.BackColor = Color.White; pb5.BackColor = Color.White; pb9.BackColor = Color.White;
					checkTag = pb1.Tag.ToString();
				}
			}

			if (pb3.Tag.ToString() != "?")
			{
				if (pb3.Tag == pb6.Tag && pb3.Tag == pb9.Tag)
				{
					pb3.BackColor = Color.White; pb6.BackColor = Color.White; pb9.BackColor = Color.White;
					checkTag = pb3.Tag.ToString();
				}

				if (pb3.Tag == pb5.Tag && pb3.Tag == pb7.Tag)
				{
					pb3.BackColor = Color.White; pb5.BackColor = Color.White; pb7.BackColor = Color.White;
					checkTag = pb3.Tag.ToString();
				}
			}

			if (pb5.Tag.ToString() != "?")
			{
				if (pb4.Tag == pb5.Tag && pb4.Tag == pb6.Tag)
				{
					pb4.BackColor = Color.White; pb5.BackColor = Color.White; pb6.BackColor = Color.White;
					checkTag = pb5.Tag.ToString();
				}
				if (pb2.Tag == pb5.Tag && pb2.Tag == pb8.Tag)
				{
					pb2.BackColor = Color.White; pb5.BackColor = Color.White; pb8.BackColor = Color.White;
					checkTag = pb5.Tag.ToString();
				}
			}

			if (pb7.Tag.ToString() != "?")
			{
				if (pb7.Tag == pb8.Tag && pb7.Tag == pb9.Tag)
				{
					pb7.BackColor = Color.White; pb8.BackColor = Color.White; pb9.BackColor = Color.White;
					checkTag = pb7.Tag.ToString();
				}
			}

			return checkTag;
		}
		private bool IsThereAWinner()
		{
			if (_movesNumber <= 4)
			{
				++_movesNumber;
				return false;
			}

			string checkTag = CheckWinnerReturnTag();
			if (checkTag != "?")
			{
				EndTheGame(checkTag);
				return true;
			}


			if (_movesNumber == 9)
			{
				EndTheGame("?");
				return true;
			}

			_movesNumber++;
			return false;
		}
		private void ButtonClicked(PictureBox pictureBoxName)
		{
			if (pictureBoxName.Tag.ToString() != "?")
			{
				MessageBox.Show("You Can't Choose This One", "Wrong Choice", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}

			if (lbTurn.Tag.ToString() == "X")
			{
				pictureBoxName.Image = Resources.X;
				pictureBoxName.Tag = "X";
			}
			else
			{
				pictureBoxName.Image = Resources.O;
				pictureBoxName.Tag = "O";
			}

			if (!IsThereAWinner())
			{
				ChangeTurn();
			}
		}

		private void EndTheGame(String WinnerTag)
		{
			lbTurn.Text = "Game Over";
			lbTurn.TextAlign = ContentAlignment.MiddleCenter;

			if (WinnerTag == "?")
			{
				lbWinning.Text = "Draw : - )";
				lbWinning.TextAlign = ContentAlignment.BottomLeft;
				DisablePictureBoxes();
				if (MessageBox.Show("Draw", "Result {X / O}!", MessageBoxButtons.OKCancel, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2) == DialogResult.OK)
				{
					RestartTheGame();
				}
				return;
			}

			if (WinnerTag == "X")
			{
				lbWinning.Text = "Player 1 {x}.";
				lbWinning.TextAlign = ContentAlignment.MiddleCenter;
				DisablePictureBoxes();
				if (MessageBox.Show("Player 1", "Result {X / O}!", MessageBoxButtons.OKCancel, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2) == DialogResult.OK)
				{
					RestartTheGame();
				}
				return;
			}

			if (WinnerTag == "O")
			{
				lbWinning.Text = "Player 2 {O}.";
				lbWinning.TextAlign = ContentAlignment.MiddleCenter;
				DisablePictureBoxes();
				if (MessageBox.Show("Player 2", "Result {X / O}!", MessageBoxButtons.OKCancel, MessageBoxIcon.Information, MessageBoxDefaultButton.Button2) == DialogResult.OK)
				{
					RestartTheGame();
				}
				return;
			}
		}


		// One Event :
		private void PictureBox_Click(object sender, EventArgs e)
		{
			ButtonClicked((PictureBox)sender);
		}
		//
		private void pb1_Click(object sender, EventArgs e)
		{
			ButtonClicked((PictureBox)sender);
		}
		private void pb2_Click(object sender, EventArgs e)
		{
			ButtonClicked((PictureBox)sender);
		}
		private void pb3_Click(object sender, EventArgs e)
		{
			ButtonClicked((PictureBox)sender);
		}
		private void pb4_Click(object sender, EventArgs e)
		{
			ButtonClicked((PictureBox)sender);
		}
		private void pb5_Click(object sender, EventArgs e)
		{
			ButtonClicked((PictureBox)sender);
		}
		private void pb6_Click(object sender, EventArgs e)
		{
			ButtonClicked((PictureBox)sender);
		}
		private void pb7_Click(object sender, EventArgs e)
		{
			ButtonClicked((PictureBox)sender);
		}
		private void pb8_Click(object sender, EventArgs e)
		{
			ButtonClicked((PictureBox)sender);
		}
		private void pb9_Click(object sender, EventArgs e)
		{
			ButtonClicked((PictureBox)sender);
		}
		//

		private void btnRestart_Click(object sender, EventArgs e)
		{
			RestartTheGame();
		}
		private void btnExit_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
